import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("spects_data.csv")
df.drop_duplicates(subset='Unique ID', keep='first', inplace=True)
df.replace('', pd.NA, inplace=True)
df.dropna(subset=['Wear Specs'], inplace=True)

yes_no_cols = ["Whether parents have specs", "English speaker", "Migrated within country", "Migrated overseas",
               "Has Diabetes", "Has Gym Subscription", "Has OTT subscription", "Likes spicy food",
               "Likes desserts", "Wants to change career", "Has debt", "Has kids",
               "Drinks alcohol", "Smoker", "Wear Specs"]

for col in yes_no_cols:
    df[col] = df[col].map({'Yes': 1, 'No': 0})

df.rename(columns={'Wear Specs': 'wears_specs'}, inplace=True)

for col in df.select_dtypes(include='number'):
    df[col].fillna(df[col].median(), inplace=True)

df = df[df['Country'].notna()]
df = df[df['wears_specs'].notna()]
df = df[df['Country'] != '']

correlation = df.corr(numeric_only=True)['wears_specs'].sort_values(ascending=False)
top_features = correlation[1:6].index.tolist()

def get_country_cutoffs(df, feature, country_list):
    cutoffs = {}
    for country in country_list:
        country_df = df[df['Country'] == country]
        sorted_df = country_df[[feature, 'wears_specs']].dropna().sort_values(by=feature)
        for i in range(1, len(sorted_df)):
            val = sorted_df[feature].iloc[i]
            filtered = sorted_df[sorted_df[feature] >= val]
            if len(filtered) >= 3 and filtered['wears_specs'].mean() >= 0.7:
                cutoffs[country] = val
                break
    return cutoffs

country_list = df['Country'].unique()
cutoff_dict = {}
for feature in top_features:
    cutoff_dict[feature] = get_country_cutoffs(df, feature, country_list)

india_df = df[df['Country'] == 'India']
other_countries = [c for c in country_list if c != 'India']

expected_extra_specs = 0

for feature in top_features:
    base_cutoffs = [cutoff_dict[feature][c] for c in other_countries if c in cutoff_dict[feature]]
    if not base_cutoffs:
        continue
    avg_cutoff = sum(base_cutoffs) / len(base_cutoffs)
    india_actual = india_df['wears_specs'].sum()
    india_predicted = india_df[india_df[feature] >= avg_cutoff].shape[0]
    extra = india_predicted - india_actual
    print(f"{feature}: Expected specs wearers = {india_predicted}, Actual = {india_actual}, Underreported by = {extra}")
    expected_extra_specs += max(extra, 0)

print(f"\nTotal Estimated Underreported Cases in India: {expected_extra_specs}")

for feature in top_features:
    plt.figure(figsize=(8, 5))
    sns.boxplot(data=df, x='Country', y=feature, hue='wears_specs')
    plt.title(f"{feature} vs Specs by Country")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()
