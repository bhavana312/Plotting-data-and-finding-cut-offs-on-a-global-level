import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("specs_data.csv")
df.drop_duplicates(subset='Unique ID', keep='first', inplace=True)
df.replace('', pd.NA, inplace=True)
df.dropna(subset=['Wear Specs'], inplace=True)

yes_no_columns = [
    "Whether parents have specs", "English speaker", "Migrated within country", "Migrated overseas",
    "Has Diabetes", "Has Gym Subscription", "Has OTT subscription", "Likes spicy food",
    "Likes desserts", "Wants to change career", "Has debt", "Has kids",
    "Drinks alcohol", "Smoker", "Wear Specs"
]

for col in yes_no_columns:
    df[col] = df[col].map({'Yes': 1, 'No': 0})

df.rename(columns={'Wear Specs': 'wears_specs'}, inplace=True)

for col in df.select_dtypes(include='number'):
    df[col].fillna(df[col].median(), inplace=True)

df.drop(columns=['Unique ID', 'Country', 'Education Status', 'Gender', 'Marital Status'], inplace=True)

corr = df.corr(numeric_only=True)['wears_specs'].sort_values(ascending=False)
sns.heatmap(df.corr(numeric_only=True), annot=True, fmt=".2f", cmap='coolwarm')
plt.title("Correlation Heatmap with Target")
plt.show()

low_corr_cols = corr[abs(corr) < 0.1].index.tolist()
df = df.drop(columns=low_corr_cols)

numeric_cols = df.select_dtypes(include='number').drop(columns='wears_specs').columns

for col in numeric_cols:
    temp = df[[col, 'wears_specs']].dropna().sort_values(by=col)
    for i in range(1, len(temp)):
        cutoff = temp[col].iloc[i]
        above_cutoff = temp[temp[col] >= cutoff]
        if len(above_cutoff) >= 3:
            percentage = above_cutoff['wears_specs'].mean()
            if percentage >= 0.7:
                print(f"{col}: Cutoff = {cutoff}, Specs Wearers = {percentage*100:.2f}%")
                break

binary_cols = [col for col in df.columns if df[col].nunique() == 2 and col != 'wears_specs']

for col in binary_cols:
    stats = df.groupby(col)['wears_specs'].mean()
    print(f"\n{col} vs Specs Wear Rate:\n{stats}")

for col in numeric_cols:
    plt.figure(figsize=(6,4))
    sns.histplot(data=df, x=col, hue='wears_specs', bins=15, kde=True)
    plt.title(f"{col} Distribution by Specs")
    plt.show()

for col in numeric_cols:
    plt.figure(figsize=(6,4))
    sns.boxplot(data=df, x='wears_specs', y=col)
    plt.title(f"{col} vs Specs")
    plt.show()

plt.figure(figsize=(6,4))
sns.scatterplot(data=df, x='IQ', y='Total Time spent working in front of a screen', hue='wears_specs')
plt.title("IQ vs Screen Time by Specs Usage")
plt.show()

corr.to_csv("correlation_summary.csv")
df.to_csv("cleaned_specs_data.csv", index=False)
